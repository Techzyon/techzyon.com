import config
import sys
import xbmcgui
import xbmcplugin
 
from aussieaddonscommon import session
from aussieaddonscommon import utils
 
_url = sys.argv[0]
_handle = int(sys.argv[1])
 
 
def parse_m3u8(data, url, qual=-1):
    """
   Parse the retrieved m3u8 stream list into a list of dictionaries
   then return the url for the highest quality stream.
   """
    ver = 0
    if '#EXT-X-VERSION:3' in data:
        ver = 3
        data.remove('#EXT-X-VERSION:3')
    if '#EXT-X-VERSION:4' in data:
        ver = 4
 
    if ver != 4:
        count = 2
        m3u_list = []
        while count < len(data):
            line = data[count]
            utils.log('Line: {0}'.format(line))            
            values = line.split(',')
            for value in values:
                if value.startswith('BANDWIDTH'):
                    bw = value
                elif value.startswith('RESOLUTION'):
                    res = value
            url = data[count+1]            
            m3u_list.append(
                dict([bw.split('='), res.split('='), ['URL', url]]))
            count += 2
        sorted_m3u_list = sorted(m3u_list, key=lambda k: int(k['BANDWIDTH']))
        utils.log('Available streams are: {0}'.format(sorted_m3u_list))        
        stream = sorted_m3u_list[qual]['URL']       
    else:
        stream = url
 
    return stream
 
 
def play_video(params):
    """
   Determine content and pass url to Kodi for playback
   """
    try:
        with session.Session() as sess:
            url = params['hlsurl']
            sess.headers.update({'User-Agent': config.USER_AGENT})
            data = sess.get(url.replace("/play/","/get/")).text.splitlines()
        streamurl = parse_m3u8(data, url) + '|User-agent=' + config.USER_AGENT
#       streamurl = url
        utils.log('Parsed Data: {0}'.format(streamurl))
        play_item = xbmcgui.ListItem(path=streamurl)
        xbmcplugin.setResolvedUrl(_handle, True, play_item)
    except Exception:
        utils.handle_error('Unable to play video')