import json
import sys
import uuid
import urllib
import urlparse
import xbmcaddon
import xbmcgui
import requests
import utils
import config

from classes import MenuItem

ADDON = xbmcaddon.Addon()

def fetch_url(url):

    headers = {
        'Origin': 'https://7plus.com.au', 
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'cross-site',
        'User-Agent': config.USER_AGENT
    }

    res = requests.get(url, headers=headers).text
    res = res.encode('utf-8', 'ignore')
    return res

def get_market_id():

    market_id = ADDON.getSetting("market-id")

    if len(market_id):
        return market_id

    else:
        try:
            data = json.loads(fetch_url(config.MARKET_URL))
            market_id = str(data.get('_id'))
            postcode = str(data.get('postcode'))
            ADDON.setSetting("market-id", market_id)
            ADDON.setSetting("postcode", postcode)
            return market_id

        except session.requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                return '15'
    
def api_query(url, pid='web'):
    query_string = urllib.urlencode({'market-id': get_market_id(), 'platform-id': pid})
    return json.loads(fetch_url('{0}?{1}'.format(url, query_string)))


def get_categories():
    categories_list = []

    json_data = api_query(config.CONTENT_URL)
    for item in json_data.get('items'):

        if item.get('title') == 'Categories':
            genre_data = item
            break

    for genre in genre_data.get('linkImageItems'):
        c = MenuItem()
        c.title = genre['title']
        c.thumb = genre['image']['url']
        c.url = urlparse.urljoin(config.CONTENT_URL, genre['contentLink'].get('url').lstrip('/'))
        categories_list.append(c)

    categories_list.sort(key=lambda x: x.title)
    categories_list.insert(0, MenuItem(title='Live TV'))
    categories_list.append(MenuItem(title='Settings'))

    return categories_list

def get_series_list(params):
    """Fetch the index of all shows available for a given category"""
    series_list = []
    seen = set()
    json_data = api_query(params.get('url'), pid='mobile')

    for item in json_data.get('items'):

        if 'mediaItems' not in item or not item['mediaItems']:
            continue

        for series in item.get('mediaItems'):
            if 'title' not in series:
                continue
            s = MenuItem()
            s.title = series['title']
            s.thumb = series['image']['url']
            s.url = urlparse.urljoin(config.CONTENT_URL, series['contentLink'].get('url').lstrip('/'))
            if s.title not in seen:
                series_list.append(s)
                seen.add(s.title)

    return sorted(series_list)

def get_programs_list(params):
    """Fetch the episode list for a given series"""
    program_list = []
    json_data = api_query(params.get('url'))

    def recurse(obj):

        if isinstance(obj, dict):

            if 'cardData' in obj and 'infoPanelData' in obj and 'playerData' in obj:
                p = MenuItem(playable=True)

                p.url = obj['playerData']['videoUrl']
                p.thumb = obj['cardData']['image']['url']
                p.description = obj['infoPanelData']['shortSynopsis']
                
                if obj['cardData']['image']['altTag']:
                    p.title = obj['cardData']['image']['altTag']
                else:
                    p.title = obj['infoPanelData']['title']
                
                duration = obj['infoPanelData']['subtitle'].split(' ')
                if len(duration) == 2:
                    p.duration = int(duration[0][:-1])*3600 + int(duration[1][:-1])*60
                else:
                    p.duration = int(duration[0][:-1])*60
                
                if 'airDate' in obj['infoPanelData']:
                    p.description += " ({})".format(obj['infoPanelData']['airDate'])
                
                tab = p.title.split()
                if tab[0] == 'Season' and tab[2] == 'Episode':
                    p.season, p.episode = int(tab[0]), int(tab[3])

                if 'classification' in obj['infoPanelData']:
                    p.mpaa = obj['infoPanelData'].get('classification')

                program_list.append(p)

            else:
                [recurse(obj[_]) for _ in obj]

        elif isinstance(obj, list):
            [recurse(_) for _ in obj]

    recurse(json_data)

    return program_list[::-1]

def get_program(params):
    utils.log('Fetching program information for: {0}'.format(params.get('title')))

    program = MenuItem(playable=True)
    program.from_kodi_url(sys.argv[2])
    program.url = params.get('url')
    program.url = program.url.replace("[", "{")
    program.url = program.url.replace("]", "}")
    program.url = program.url.format(ppId='', deviceId=uuid.uuid4(), pc=ADDON.getSetting("postcode"), postcode=ADDON.getSetting("postcode"), advertid='null', deliveryId='csai', deviceType='web', platformType='web')
    data = fetch_url(program.url)

    try:
        program_data = json.loads(data)
    except Exception:
        utils.log("Bad program data: %s" % program_data)
        raise Exception("Error decoding program information.")

    if 'name' in program_data.get('media'):
        program.title = program_data['media']['name']

    if 'text_tracks' in program_data.get('media'):
        if len(program_data['media'].get('text_tracks')) == 0:
            utils.log("No subtitles available for this program")
        else:
            utils.log("Subtitles are available for this program")
            program.subtitle = program_data['media']['text_tracks'][0].get('src')
    
    # If no DASH streams available, use MP4
    mp4_list = []
    for source in program_data['media'].get('sources'):

        src = source.get('src')

        if 'videoType=live' in program.url:
            program.url = src
            return program

        elif source.get('container') == 'MP4':
            if src:
                res = source.get('height')
                mp4_list.append({'SRC': src, 'RES': res})

    mp4_list = sorted(mp4_list, key=lambda x: x['RES'], reverse=True)

    if len(mp4_list):
        stream = mp4_list[0]
        program.url = stream['SRC']

        if program.url:
            utils.log('Using {0}p MP4 stream'.format(stream['RES']))
            return program

    # Try for DASH first if enabled
    for source in program_data['media'].get('sources'):
        if source.get('type') == 'application/dash+xml':
            
            if 'hbbtv' in source.get('src'):
                continue
            
            program.url = source.get('src')
            program.dash = True

            if 'key_systems' in source and 'com.widevine.alpha' in source['key_systems']:
                program.drm_key = source['key_systems']['com.widevine.alpha']['license_url']
                utils.log('Using DASH/Widevine stream...')
            else:
                utils.log('Using DASH stream...')
    return program

def get_live():
    json_data = api_query(config.CONTENT_URL + 'live-tv')

    for item in json_data.get('items'):
        if item.get('title') == 'On Now':
            json_data = item['mediaItems']
            break

    channel_list = []
    for channel in json_data:

        schedule = channel['schedule'][0]['infoPanelData']
        schedule['subTitle'] = schedule['subTitle'].replace(schedule['title'], '').strip()

        c = MenuItem(playable=True)

        c.thumb = channel['channelLogo']['url']
        c.title = '[{0}] {1}'.format(channel.get('name'), schedule['title'].encode('ascii', 'ignore'))
        if len(schedule['subTitle']):
            c.title += ' - {}'.format(schedule['subTitle'])
        c.description = schedule['shortSynopsis']
        c.url = channel['schedule'][0]['playerData'].get('videoUrl')
        channel_list.append(c)

    return channel_list
