SHOWLIST_URL = "http://vod.ten.com.au/config/android-v4"
EPISODEQUERY_URL = "https://v.tenplay.com.au/api/videos/bcquery?command=search_videos&state=act&isMetro=false{0}&get_item_count=true&page_size=30&page_number={1}&video_fields=id,shortDescription,length,videoStillURL,startDate,endDate,ssa_url&custom_fields=start_date_app,clip_title,tv_channel,tv_show,restriction_bymember,tv_season,tv_week,web_content_url,program_classification&platformgroup=ott&platform=YW5kcm9pZA%3D%3D"
BRIGHTCOVE_URL = "http://c.brightcove.com/services/mobile/streaming/index/master.m3u8?videoId={0}"
USER_AGENT = 'tenplay/v4.0.22 Dalvik/2.1.0 (Linux; U; Android 8..00; SM-G960F Build/R16NW)'
