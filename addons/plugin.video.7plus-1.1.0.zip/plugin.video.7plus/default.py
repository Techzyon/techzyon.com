'''
import sys
import xbmcaddon
import xbmcgui

from resources.lib import menu, utils, play, drmhelper

if __name__ == "__main__":
    params = utils.uri_to_dict(sys.argv[2])

    if len(params) == 0:
        menu.make_categories_list()

    elif 'action' in params:
        action = params.get('action')
        
        if action == 'list_categories':
            if params['title'] == 'Live TV':
                menu.make_live_list(sys.argv[2])
            elif params['title'] == 'Settings':
                xbmcaddon.Addon().openSettings()
            else:
                menu.make_series_list(params)
        elif action == 'list_series':
            menu.make_programs_list(params)
        elif action == 'list_programs':
            play.play(params)
        elif action == 'reinstall_widevine_cdm':
            drmhelper.get_widevinecdm()
        elif action == 'update_ia':
            ia = xbmcaddon.Addon('inputstream.adaptive')
            if xbmcgui.Dialog().yesno('Update', 'Current version: {0}\nUpdate?'.format(ia.getAddonInfo('version'))):
                drmhelper.get_ia_direct(update=True, drm=True)



'''

import sys
import xbmc
import xbmcaddon
import xbmcgui

from resources.lib import utils, menu, play, comm, drmhelper

def router(paramstring):
    params = utils.uri_to_dict(paramstring)
    
    if 'action' in params:

        if params['action'] == 'list_series':
            
            if params['title'] == 'Live TV':
                menu.make_menu(comm.get_live(), next='play')

            elif params['title'] == 'Settings':
                xbmcaddon.Addon().openSettings()

            else:
                menu.make_menu(comm.get_series_list(params), next='list_programs', sort=True)

        elif params['action'] == 'list_programs':
            menu.make_menu(comm.get_programs_list(params), next='play')

        elif params['action'] == 'play':
            play.play(params)

        elif params['action'] == 'reinstall_widevine_cdm':
            drmhelper.get_widevinecdm()

        elif params['action'] == 'update_ia':
            if xbmcgui.Dialog().yesno('Update', 'Current version: {0}\nUpdate?'.
                    format(xbmcaddon.Addon('inputstream.adaptive').getAddonInfo('version'))):
                drmhelper.get_ia_direct(update=True, drm=True)

    else:
        menu.make_menu(comm.get_categories(), next='list_series')

if __name__ == '__main__':
    router(sys.argv[2][1:])
