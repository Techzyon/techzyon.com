import classes
import comm
import json
import os
import sys
import urllib2
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import utils
import config

from pycaption.srt import SRTWriter
from pycaption.webvtt import WebVTTReader

ADDON = xbmcaddon.Addon()
_handle = int(sys.argv[1])

def play(params):
    try:
        p = comm.get_program(params)

        # enable HD streams
        if ADDON.getSetting('hd_enabled') == 'true' and '&rule=sd-only' in p.url:
            p.url = p.url.replace('&rule=sd-only', '')

        p.url += '|User-Agent=%s' % config.USER_AGENT
        listitem = xbmcgui.ListItem(path=p.url)
        
        if p.has('dash'):

            import drmhelper

            if drmhelper.check_inputstream(drm=p.has('drm_key')):
                listitem.setProperty('inputstreamaddon', 'inputstream.adaptive')
                listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')

                if p.has('drm_key'):
                    listitem.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                    listitem.setProperty('inputstream.adaptive.license_key', p.get('drm_key') + '|Content-Type=application%2Fx-www-form-urlencoded|A{SSM}|')
            else:
                xbmcplugin.setResolvedUrl(_handle, True, xbmcgui.ListItem(path=None))
                return

        # Pull subtitles if available
        if p.has('subtitle'):
            utils.log('Enabling subtitles: {0}'.format(p.subtitle))
            
            profile = ADDON.getAddonInfo('profile')
            subfilename = xbmc.translatePath(os.path.join(profile, 'plus7-subtitle.srt'))
            profiledir = xbmc.translatePath(os.path.join(profile))
            
            if not os.path.isdir(profiledir):
                os.makedirs(profiledir)

            webvtt_data = urllib2.urlopen(p.subtitle).read().decode('utf-8')
            
            if webvtt_data:

                with open(subfilename, 'w') as f:
                    webvtt_subtitle = WebVTTReader().read(webvtt_data)
                    srt_subtitle = SRTWriter().write(webvtt_subtitle)
                    srt_unicode = srt_subtitle.encode('utf-8')
                    f.write(srt_unicode)

            if hasattr(listitem, 'setSubtitles'):
                # This function only supported from Kodi v14+
                listitem.setSubtitles([subfilename])

        # Play video
        utils.log('Attempting to play: {}'.format(p.title))
        xbmcplugin.setResolvedUrl(_handle, True, listitem=listitem)

    except Exception:
        utils.handle_error('Unable to play video')
