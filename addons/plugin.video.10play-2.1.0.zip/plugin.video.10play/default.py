import sys
import xbmc

from resources.lib import utils, menu, play, comm

def router(paramstring):
    params = utils.uri_to_dict(paramstring)
    
    if 'action' in params:

        if params['action'] == 'listshows':
            menu.make_menu(comm.get_shows(), next='listseasons')

        elif params['action'] == 'listseasons':
            menu.make_menu(comm.get_seasons(params), next='listepisodes', sort=True)

        elif params['action'] == 'listepisodes':
            menu.make_menu(comm.get_episodes(params), next='play')

        elif params['action'] == 'play':
            play.play_video(params)
    else:
        menu.make_menu(comm.get_genres(), next='listshows', sort=True)

if __name__ == '__main__':
    router(sys.argv[2][1:])
