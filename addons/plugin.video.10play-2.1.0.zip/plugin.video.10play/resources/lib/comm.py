import config
import json
import requests
import urllib
import utils

from classes import MenuItem

def fetch_url(url):

    headers = {
        'Origin': 'https://10play.com.au', 
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'cross-site',
        'User-Agent': config.USER_AGENT
    }

    res = requests.get(url, headers=headers).text
    res = res.encode('utf-8', 'ignore')
    return res

def get_shows():
    data = json.loads(fetch_url(config.SHOWLIST_URL))
    listing = []

    for show in data['Browse TV']['Shows']:
        s = MenuItem()
        s.id = int(show['id'])
        s.title = show['title']
        s.query = show['query']
        s.genre = show['genre']
        s.fanart = show['tvBackgroundURL']
        s.icon = show['logoURL']
        s.thumb = show['logoURL']
        s.banner = show['tvBannerURL']
        s.nb_seasons = len(show['seasons'])
        listing.append(s)

    return listing

def get_seasons(params):
    data = json.loads(fetch_url(config.SHOWLIST_URL))
    listing = []

    for show in data['Browse TV']['Shows']:

        if int(show['id']) != int(params['id']):
            continue

        for season in show['seasons']:

            s = MenuItem()
            s.show_id = int(show['id'])
            s.icon = show['logoURL']
            s.thumb = show['logoURL']
            s.id = season['seasonId']
            s.title = season['seasonName']
            s.query = params['query'] + season['query']
            listing.append(s)

    return listing

def get_episodes(params):

    page = params.get('page', 0)
    url = config.EPISODEQUERY_URL.format(urllib.unquote(params['query']), page)

    data = json.loads(fetch_url(url))

    listing = []
    for episode in data['items']:
        e = MenuItem(playable=True)
        e.thumb = episode['videoStillURL']
        e.fanart = urllib.unquote(params.get('fanart', ''))
        e.title = episode['customFields'].get('clip_title')
        if not e.title:
            e.title = episode.get('name')
        if 'shortDescription' in episode:
            e.description = episode['shortDescription'] + " ("+ episode['availability'] +")"
        elif 'longDescription' in episode:
            e.description = episode['longDescription'] + " ("+ episode['availability'] +")"
        else:
            e.description = episode['name'] + " ("+ episode['availability'] +")"
        e.duration = episode['length']/1000
        e.date = episode['customFields']['start_date_act']
        e.date = '{0}.{1}.{2}'.format(e.date[8:10], e.date[5:7], e.date[0:4])
        e.page = int(page)
        e.id = episode['id']
        e.url = episode['HLSURL']
        e.total_episodes = int(data['total_count'])
        if e.total_episodes > 30:
            e.query = urllib.quote(params['query'])
            e.season = params['id']
        listing.append(e)
    return listing

def get_genres():
    data = json.loads(fetch_url(config.SHOWLIST_URL))
    listing = [MenuItem(title='All shows')]
    for genre in data['Browse TV']['Genres']:
        listing.append(MenuItem(title=genre))
    return listing
