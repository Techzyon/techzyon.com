from copy import deepcopy
from base import (BaseReader, BaseWriter, CaptionSet, Caption, CaptionNode)
from exceptions import CaptionReadNoCaptions, InvalidInputError

class SRTWriter(BaseWriter):
    def write(self, caption_set):
        caption_set = deepcopy(caption_set)

        srt_captions = []

        for lang in caption_set.get_languages():
            srt_captions.append(
                self._recreate_lang(caption_set.get_captions(lang))
            )

        caption_content = u'MULTI-LANGUAGE SRT\n'.join(srt_captions)
        return caption_content

    def _recreate_lang(self, captions):
        srt = u''
        count = 1

        for caption in captions:
            srt += u'%s\n' % count

            start = caption.format_start(msec_separator=u',')
            end = caption.format_end(msec_separator=u',')
            timestamp = u'%s --> %s\n' % (start[:12], end[:12])

            srt += timestamp.replace(u'.', u',')

            new_content = u''
            for node in caption.nodes:
                new_content = self._recreate_line(new_content, node)

            # Eliminate excessive line breaks
            new_content = new_content.strip()
            while u'\n\n' in new_content:
                new_content = new_content.replace(u'\n\n', u'\n')

            srt += u"%s%s" % (new_content, u'\n\n')
            count += 1

        return srt[:-1]  # remove unwanted newline at end of file

    def _recreate_line(self, srt, line):
        if line.type_ == CaptionNode.TEXT:
            return srt + u'%s ' % line.content
        elif line.type_ == CaptionNode.BREAK:
            return srt + u'\n'
        else:
            return srt
