import sys
import re
from copy import deepcopy

from base import (BaseReader, BaseWriter, CaptionSet, Caption, CaptionNode)
from geometry import Layout
from exceptions import (
    CaptionReadError, CaptionReadSyntaxError, CaptionReadNoCaptions,
    InvalidInputError
)

# A WebVTT timing line has both start/end times and layout related settings
# (referred to as 'cue settings' in the documentation)
# The following pattern captures [start], [end] and [cue settings] if existent
TIMING_LINE_PATTERN = re.compile(u'^(\S+)\s+-->\s+(\S+)(?:\s+(.*?))?\s*$')
TIMESTAMP_PATTERN = re.compile(u'^(\d+):(\d{2})(:\d{2})?\.(\d{3})')
VOICE_SPAN_PATTERN = re.compile(u'<v(\\.\\w+)* ([^>]*)>')
OTHER_SPAN_PATTERN = (
    re.compile(
        u'</?([cibuv]|ruby|rt|lang|(\d+):(\d{2})(:\d{2})?\.(\d{3})).*?>'
    )
)  # These WebVTT tags are stripped off the cues on conversion

WEBVTT_VERSION_OF = {
    u'left': u'left',
    u'center': u'middle',
    u'right': u'right',
    u'start': u'start',
    u'end': u'end'
}

DEFAULT_ALIGNMENT = u'middle'


def microseconds(h, m, s, f):
    return (int(h) * 3600 + int(m) * 60 + int(s)) * 1000000 + int(f) * 1000


class WebVTTReader(BaseReader):
    def __init__(self, ignore_timing_errors=True, *args, **kwargs):
        """
        :param ignore_timing_errors: Whether to ignore timing checks
        """
        super(WebVTTReader, self).__init__(
            ignore_timing_errors, *args, **kwargs
        )
        self.ignore_timing_errors = ignore_timing_errors

    def detect(self, content):
        return u'WEBVTT' in content

    def read(self, content, lang=u'en-US'):
        if type(content) != unicode:
            raise InvalidInputError('The content is not a unicode string.')

        caption_set = CaptionSet()
        caption_set.set_captions(lang, self._parse(content.splitlines()))

        if caption_set.is_empty():
            raise CaptionReadNoCaptions(u"empty caption file")

        return caption_set

    def _parse(self, lines):
        captions = []
        caption = None
        found_timing = False

        for i, line in enumerate(lines):

            if u'-->' in line:
                found_timing = True
                timing_line = i
                last_start_time = captions[-1].start if captions else 0
                try:
                    caption = self._parse_timing_line(line, last_start_time)
                except CaptionReadError as e:
                    new_message = u'%s (line %d)' % (e.args[0], timing_line)
                    raise type(e), new_message, sys.exc_info()[2]

            elif u'' == line:
                if found_timing:
                    if caption.is_empty():
                        raise CaptionReadSyntaxError(
                            u'Cue without content. (line %d)' % timing_line)
                    else:
                        found_timing = False
                        captions.append(caption)
                        caption = None
            else:
                if found_timing:
                    if not caption.is_empty():
                        caption.nodes.append(CaptionNode.create_break())
                    caption.nodes.append(CaptionNode.create_text(
                        self._decode(line)))
                else:
                    # it's a comment or some metadata; ignore it
                    pass

        if caption and not caption.is_empty():
            captions.append(caption)

        return captions

    def _remove_styles(self, line):
        partial_result = VOICE_SPAN_PATTERN.sub(u'\\2: ', line)
        return OTHER_SPAN_PATTERN.sub(u'', partial_result)

    def _validate_timings(self, caption, last_start_time):
        if caption.start is None:
            raise CaptionReadSyntaxError(
                u'Invalid cue start timestamp.')
        if caption.end is None:
            raise CaptionReadSyntaxError(u'Invalid cue end timestamp.')
        if caption.start > caption.end:
            raise CaptionReadError(
                u'End timestamp is not greater than start timestamp.')
        if caption.start < last_start_time:
            raise CaptionReadError(
                u'Start timestamp is not greater than or equal'
                u'to start timestamp of previous cue.')

    def _parse_timing_line(self, line, last_start_time):
        """
        :returns: Caption
        """
        m = TIMING_LINE_PATTERN.search(line)
        if not m:
            raise CaptionReadSyntaxError(
                u'Invalid timing format.')

        caption = Caption()

        caption.start = self._parse_timestamp(m.group(1))
        caption.end = self._parse_timestamp(m.group(2))
        cue_settings = m.group(3)

        if not self.ignore_timing_errors:
            self._validate_timings(caption, last_start_time)

        if cue_settings:
            caption.layout_info = Layout(webvtt_positioning=cue_settings)

        return caption

    def _parse_timestamp(self, timestamp):
        m = TIMESTAMP_PATTERN.search(timestamp)
        if not m:
            return None

        m = m.groups()

        if m[2]:
            # Timestamp takes the form of [hours]:[minutes]:[seconds].[milliseconds]
            return microseconds(m[0], m[1], m[2].replace(u":", u""), m[3])
        else:
            # Timestamp takes the form of [minutes]:[seconds].[milliseconds]
            return microseconds(0, m[0], m[1], m[3])

    def _decode(self, s):
        """
        Convert cue text from WebVTT XML-like format to plain unicode.
        :type s: unicode
        """
        s = s.strip()
        # Covert voice span
        s = VOICE_SPAN_PATTERN.sub(u'\\2: ', s)
        # TODO: Add support for other WebVTT tags. For now just strip them
        # off the text.
        s = OTHER_SPAN_PATTERN.sub(u'', s)
        # Replace WebVTT special XML codes with plain unicode values
        s = s.replace(u'&lt;', u'<')
        s = s.replace(u'&gt;', u'>')
        s = s.replace(u'&lrm;', u'\u200e')
        s = s.replace(u'&rlm;', u'\u200f')
        s = s.replace(u'&nbsp;', u'\u00a0')
        # Must do ampersand last
        s = s.replace(u'&amp;', u'&')
        return s

