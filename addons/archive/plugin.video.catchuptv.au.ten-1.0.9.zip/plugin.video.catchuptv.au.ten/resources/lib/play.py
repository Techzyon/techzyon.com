import config
import sys
import xbmcgui
import xbmcplugin
 
from aussieaddonscommon import session
from aussieaddonscommon import utils
 
_url = sys.argv[0]
_handle = int(sys.argv[1])
  
def play_video(params):
    """
   Determine content and pass url to Kodi for playback
   """
    try:
        url = params['hlsurl'] + '|User-agent=' + config.USER_AGENT
        utils.log('Parsed Data: {0}'.format(url))
        play_item = xbmcgui.ListItem(path=url)
        xbmcplugin.setResolvedUrl(_handle, True, play_item)
    except Exception:
        utils.handle_error('Unable to play video')